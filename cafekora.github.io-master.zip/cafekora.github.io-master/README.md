The static website for thekoracafe.com, lovingly hosted by github :-)
