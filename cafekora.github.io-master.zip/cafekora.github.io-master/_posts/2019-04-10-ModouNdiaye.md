---
layout: page
title:  "Modou Ndiaye UK gigs"
teaser: "a few concert dates"
breadcrumb: true
categories:
    - concerts
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---
Modou Ndiaye (Mamadou Cissokho and a 5-piece band) have a few UK gigs in April and May, as follows:

* The Workshop at Exeter Phoenix, 18th April

* The Globe in Hay on Wye, 20th April

* Chapel Arts Centre, Bath, 24th May
