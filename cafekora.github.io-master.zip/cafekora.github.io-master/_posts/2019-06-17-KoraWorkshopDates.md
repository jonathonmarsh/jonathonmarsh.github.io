---
layout: page
title:  "Kora Workshop September Dates"
breadcrumb: true
categories:
    - koranews
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---

**Kora Workshop September Dates**

The Kora Workshop have announced a week-long workshop in a very beautiful part of France. It runs from 18th – 25th September 2019 and is suitable for kora students of all levels.

Full Details from their website: <https://www.thekoraworkshop.co.uk/product/sept-2019-workshop-in-france/> 
