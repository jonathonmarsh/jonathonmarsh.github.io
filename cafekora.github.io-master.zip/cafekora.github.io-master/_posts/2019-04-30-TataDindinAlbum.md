---
layout: page
title:  "Tata Dindin New Album"
teaser: "Kano"
breadcrumb: true
categories:
    - koranews
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---

**Tata Dindin Jobarteh New Album**

Tata dindin Jobarteh and his Salam band released a new album "Kano" on all digital platforms today (April 30 2019). 
