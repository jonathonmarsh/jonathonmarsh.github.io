---
layout: page
title:  "Africa International Festival Lineup"
teaser: "Wurzburg Germany"
breadcrumb: true
categories:
    - concerts
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---
The 32nd Africa International Festival takes place in Wurzburg Germany, from 30 May to 2 June 2019. Among the many headline acts are Anna & Saliou Cissokho. Anna is a singer from Hamburg, while Saliou Cissokho is a kora player from Casamance.
<https://www.africafestival.org/en/>
