---
layout: page
title:  "Youssoupha Cissokho New Album"
teaser: "Diassing Jalikunda"
breadcrumb: true
categories:
    - koranews
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---
Senegalese kora player Youssoupha Cissokho has a new recording, titled Diassing Jalikunda, named for his family's compound in Casamance.
You can listen to (and buy) tracks here: <https://twelveeightrecords.com/youssoupha-cissokho>
