---
layout: page
title:  "Wooden Roots Kora & Balafon Tuition"
teaser: "with Sefo Kanuteh in Suffolk, UK"
breadcrumb: true
categories:
    - koranews
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---

**Workshop Announcement**

Learn Kora & Balafon with Sefo Kanuteh on May 26th 2019 at Wooden Roots, Rendlesham, Suffolk.

Enjoy 2 hours guided tuition with the balafon, take a break - have some lunch and then relax into 2 hours with the kora - all guided by Sefo Kanuteh in our beautiful studio.

Limited Spaces

£35

11am - 4pm

Call: 07846 761145

Email: info@woodenroots.com

<https://www.woodenroots.com>
