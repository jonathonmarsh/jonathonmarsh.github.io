---
layout: page
title:  "Sona Jobarteh Concert Dates"
teaser: "Worldwide 2019/2020 concerts"
breadcrumb: true
categories:
    - concerts
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---
Sona Jobarteh's world tour continues with dates in France, Netherlands and Germany and a visit to the USA in May 2020.
 	 	 	 	 	 
- 5th November New Morning, Paris, France
 	 	 	 	 	 
- 14th November Frankfurter Hof, Mainz, Germany 

- 16th November Kölner Philharmonie, Cologne, Germany

- 25th January 2020 Centre Francois Rabelais, Changé, France

- 8th February 2020 Muziekgebouw Eindhoven, Eindhoven, Netherlands

- 6th April 2020 Motorco Music Hall, Durham, NC, US

- 10th April 2020 Le Roudour, Saint-Martin-des-Champs, France

- 16th May 2020 Espace James Chambaud, Lons, France

- 19th May 2020 Salle Nougaro, Toulouse, France

-
