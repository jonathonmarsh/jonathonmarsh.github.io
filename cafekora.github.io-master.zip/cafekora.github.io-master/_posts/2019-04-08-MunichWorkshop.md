---
layout: page
title:  "Kora Workshop in Munich"
teaser: "with Marcus Ottschofski on May 4th"
breadcrumb: true
categories:
    - koranews
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---

**Workshop Announcement**

Kora Workshop with Marcus Ottschofski in Munich, Germany on Saturday 4th May

Koraworkshop am Freien Musikzentrum München:
Samstag, 04.05. 11:00 - 18:00 Uhr, Anmeldung unter info@freies-musikzentrum.de
