---
layout: page
title:  "Sona Jobarteh Concert Dates"
teaser: "Worldwide 2019 concerts"
breadcrumb: true
categories:
    - concerts
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---
Sona Jobarteh continues to rack up the air miles with a trip down under for WOMAD in Adelaide, South Australia and WOMAD in New Plymouth New Zealand in March. She plays some big venues in California in June and has various European Festival appearances lined up. 

- 	20th January Celtic Connections	Scotland
 	 	 	 	 	 
- 	9th March	Womadadelaide	Australia 	 	 	 	 	 
- 	11th March Womadadelaide	Australia	
- 	15th March	Womad New Plymouth	New Zealand		 	 	 	 
- 	16th March	Womad New Plymouth	New Zealand
 	 	 	 	 	 
- 	19th March The Gulbenkian Theatre	Canterbury, UK
 	 	 	 	 	 
- 	12th April Kings Place	London, UK
 	 	 	 	 	 
- 	8th-9th June Hollywood Bowl	California, USA 	 	 	 	 
- 	12th June		SF Jazz Festival	California, USA
- 	13th June	Santa Cruz, California, USA
 	 	 	 	 	 
- 	11th July	Jazz Festival	Copenhagen, Denmark	
 	 	 	 	 	 
- 	16th November	Philharmonie	Cologne, Germany
