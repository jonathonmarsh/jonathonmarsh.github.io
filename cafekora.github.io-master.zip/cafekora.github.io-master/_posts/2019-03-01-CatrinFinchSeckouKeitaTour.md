---
layout: page
title:  "Catrin Finch and Seckou Keita Tour Dates"
teaser: "UK 2019 concerts"
breadcrumb: true
categories:
    - concerts
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---
Various UK dates announced for Catrin Finch and Seckou Keita in 2019 (and one in Vienna) after playing in France earlier in the year. The venues include a tour of the Scottish Highlands and Islands in June, including gigs on the Islands of Lewis and Skye.

- 22 May Neuadd Dwyfor, Pwllheli, United Kingdom
- 23 May Warwick Arts Centre,  Coventry, United Kingdom
- 24 May The Haymarket, Anvil Arts, Basingstoke, United Kingdom
- 26 May Wiener Konzerthaus, Wien, Austria
 
- 07 Jun Wiltshire Music Centre, Bradford-on-avon, United Kingdom

- 19 Jun Tolbooth, Stirling, United Kingdom
- 20 Jun St Mary's Space, Fasnacloich, United Kingdom
- 21 Jun The Macphail Centre, Ullapool, United Kingdom
- 24 Jun An Lanntair, Stornoway, United Kingdom
- 25 Jun Aros Community Theatre, Portree, United Kingdom
- 26 Jun Eden Court, Inverness, United Kingdom
- 27 Jun The Lemon Tree, Aberdeen, United Kingdom
- 29 Jun East Neuk Festival 2019, Anstruther, United Kingdom
 
- 18 Jul  The Abbeydale Theatre, Sheffield, United Kingdom
- 19 Jul Guiting Festival, Cheltenham, United Kingdom
- 20 Jul The Arts Hall, Lampeter University Campus ,Lampeter, United Kingdom
 
- 24 Aug Towersey Festival, Oxford, United Kingdom
 
- 18 Oct The Live Room, Saltaire, Shipley, United Kingdom
- 19 Oct Musicport Festival, Whitby, United Kingdom
- 20 Oct National Centre For Early Music, York,  United Kingdom

<!--more-->
