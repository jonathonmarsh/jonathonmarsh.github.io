---
layout: page
title:  "SOAS Music Summer School 2019 Dates"
teaser: "Kora course running in London June 2019"
breadcrumb: true
categories:
    - koranews
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---
SOAS, the University of London's School of Oriental and African Studies, have announced details of their annual music summer school.
As ever, this features a 5-day workshop from Senegalese kora player (and SOAS academic) Kadialy Kouyate.

Further information can be found on the SOAS website, including booking details.

<https://store.soas.ac.uk/product-catalogue/short-courses/music-courses/kora-monday-17th-friday-21st-june-2019>
<https://www.soas.ac.uk/music/summermusicschool/index.php>
