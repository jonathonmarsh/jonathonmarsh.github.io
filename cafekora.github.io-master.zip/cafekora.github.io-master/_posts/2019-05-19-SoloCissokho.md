---
layout: page
title:  "Solo Cissokho passes away"
breadcrumb: true
categories:
    - koranews
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---

**Death of Solo Cissokho**

It is being reported on social media that kora player Solo Cissokho has died in Oslo, Norway at the age of 56. 
