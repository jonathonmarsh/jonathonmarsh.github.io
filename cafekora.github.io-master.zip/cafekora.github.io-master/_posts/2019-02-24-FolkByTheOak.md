---
layout: page
title:  "Seckou Keita at Folk by the Oak"
teaser: "UK 2019 folk festival"
breadcrumb: true
categories:
    - concerts
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---
Seckou Keita will play at the main stage at the Folk by the Oak Festival at Hatfield House, in Hertfordshire in the UK on July 14 2019
<https://www.folkbytheoak.com/line-up/main-stage/>
