---
layout: page
title:  "Lamine Cissokho 2019 Albums"
teaser: "Two forthcoming releases"
breadcrumb: true
categories:
    - koranews
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---
Lamine Cissokho will release two albums in 2019. The first is an Afro-Jazz project, the second a collaboration with Indian Classical Slide Guitarist Manish Pingle.

Sunujazz will be released on June 21st 2019.
