---
layout: page
title:  "Sona Jobarteh wins Africa Festival Artist of the Year 2018"
teaser: "Europe's largest African Music festival honours kora player "
breadcrumb: true
categories:
    - koranews
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---
Sona Jobarteh was named Artist of the Year at the 31st International Africa Festival at Wurzburg in Germany, which claims to be Europe's oldest and largest festival of African music and culture.
<https://www.africafestival.org/en/>
