---
layout: page
title:  "Kora Workshop Dates"
teaser: "in France & UK"
breadcrumb: true
categories:
    - koranews
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---

**Workshop Announcements**

The Kora Workshop will be running a week-long residential Workshop in Mas de Jammes, France from Wednesday May 15th until Wednesday 22nd.  

They will also run a workshop which includes kora, singing and mbira from Friday 9th through to Sunday 11th August, at Cwm Maddoc barns in Herefordshire, UK.

Email: info@thekoraworkshop.co.uk

<https://www.thekoraworkshop.co.uk>
