---
layout: page
title:  "World Music Workshop Festival"
teaser: "in Suffolk UK"
breadcrumb: true
categories:
    - koranews
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---

**Workshop Announcements**

11th to 14th July 2019 in Bungay, Suffolk UK

The World Music Workshop Festival has more than 30 different short workshops running over 3 days, covering singing, dance, music and percussion (see what I did there...)
In addition to kora, there's also the chance to try bala and instruments from elsewhere such as the mbira.

Modou N'diaye will provide beginner and intermediate kora tuition and will headline the Saturday night concert, performing music from his latest album 'Londo'.

<http://www.wmwfestival.com/>
