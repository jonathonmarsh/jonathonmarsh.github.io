---
layout: page
title:  "UK Kora November Concert Dates"
breadcrumb: true
categories:
    - koranews
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---

**Gigs in the UK in November/December 2019**

There are a few gigs of note in London/SE England in November/December.

- AKA Trio (Nov 14th London)

Seckou Keita's AKA Trio play at Britain's home of Folk Music, Cecil Sharp House in London.

<https://www.cecilsharphouse.org/component/content/article/21-shared/shared-events/6206-aka-trio?Itemid=163>

- Jally Kebba Susso (Nov 22nd Oxford)

Cowley Workers Social Club, Oxford 
Between Towns Road, Oxford, OX4 3LZ

<https://www.songkick.com/artists/4206436-jally-kebba-susso>

- Celebration of the Kora (Dec 4th London)

The Jazz Cafe in London has a pretty stellar looking line-up with Mamadou Diabate (Balafon) + Diabel Cissokho (Kora) + Sourakata Koite (Kora)

Full Details here: <https://thejazzcafelondon.com/event/mamadou-diabate-diabel-cissokho-sourakata-koite/> 
