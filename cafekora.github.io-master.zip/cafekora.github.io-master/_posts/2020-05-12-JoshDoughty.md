---
layout: page
title:  "Josh Doughty online lessons"
teaser: "and live stream performances"
breadcrumb: true
categories:
    - koranews
tags:
    - blog
    - content
    - post
    - post format
header:
    image_fullwidth: gallery-example-1.jpg
---
Josh Doughty has posted some really excellent YouTube tutorials. They're linked to from his website <https://joshdoughty.co.uk/online-tutorial> which also has a link to his Patreon page. Obviously, it's difficult for many kora players to earn a living with no ability to perform gigs or do face to face lessons right now due to Covid-19. So if you find the lessons useful and can afford it, I'm sure he would be very appreciative if you donate on Patreon.
<br>
<br>
Josh has also been live streaming performances on YouTube. The next one is on May 24th, more details on Facebook here: <https://www.facebook.com/events/2592988300919918>
