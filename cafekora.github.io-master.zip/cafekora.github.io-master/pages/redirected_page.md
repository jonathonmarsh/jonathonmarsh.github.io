---
title: "Re-direct page"
layout: redirect
sitemap: false
permalink: /redirect-page/
redirect_to:  "https://www.thekoracafe.com/"
---
This is just a page to demonstrate the `redirect`-layout.
