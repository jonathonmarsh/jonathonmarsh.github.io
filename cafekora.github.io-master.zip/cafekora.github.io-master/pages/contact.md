---
layout: page
comments: false
title: "Contact"
meta_title: "Contact and use our contact form"
teaser: "Get in touch? Use the contact form."
permalink: "/contact/"
---
Found something wrong? Got a question? Suggestions to improve this site? We'd love to hear from you.

<div id="wufoo-z1rqfwx0qd85f2"> Please fill out the <a href="https://thekoracafe.wufoo.com/forms/z1rqfwx0qd85f2">online form</a>. </div> 
<script type="text/javascript"> var z1rqfwx0qd85f2; (function(d, t) { var s = d.createElement(t), options = { 'userName':'thekoracafe', 'formHash':'z1rqfwx0qd85f2', 'autoResize':true, 'height':'434', 'async':true, 'host':'wufoo.com', 'header':'show', 'ssl':true }; s.src = ('https:' == d.location.protocol ?'https://':'http://') + 'secure.wufoo.com/scripts/embed/form.js'; s.onload = s.onreadystatechange = function() { var rs = this.readyState; if (rs) if (rs != 'complete') if (rs != 'loaded') return; try { z1rqfwx0qd85f2 = new WufooForm(); z1rqfwx0qd85f2.initialize(options); z1rqfwx0qd85f2.display(); } catch (e) { } }; var scr = d.getElementsByTagName(t)[0], par = scr.parentNode; par.insertBefore(s, scr); })(document, 'script'); </script>
