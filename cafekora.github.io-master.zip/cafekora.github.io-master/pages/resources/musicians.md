---
layout: page
show_meta: false
title: "Musicians"
subheadline: "Links to personal pages of kora players"
header:
   image_fullwidth: "header_homepage_13.jpg"
permalink: "/resources/musicians/"
---

* **Sona Jobarteh**

<http://www.sonajobarteh.com/>

* **Kadialy Kouyate**

<http://kadialykouyate.com/>

* **Mory Kante**

<http://www.morykante.com/>

* **Lamine Cissokho**

<https://laminecissokho.net/>

* **Ablaye Cissoko**

<http://www.ablaye-cissoko.com/>
 
* **Seckou Keita** 
 
<http://www.seckoukeita.com/>
<https://www.catrinfinchandseckoukeita.com/>

* **Jally Kebba Susso**

<http://jallykebbasusso.com/>

* **Seikou Susso**

<http://www.seikoususso.freeuk.com/>

* **Yacouba Sissoko**

<http://www.yacousiskora.com/>

* **Sura Susso**

<https://surasusso.wixsite.com/surakorasusso>

* **Vieux Aliou Cissokho**

<https://soundcloud.com/vieuxalioucissokho>

* **Ballake Sissoko**
<https://myspace.com/ballakesissoko>

* **Kane Mathis**

<http://www.kanemathis.com/>

* **Jali Fily Cissokho**

<http://jalifilycissokho.co.uk/>

* **Sura Susso**

<https://surasusso.bandcamp.com/>

* **Prince Diabate**  

<http://www.princediabate.com/>

* **Joe O'Driscoll and Sekou Kouyate**

<http://www.cumbancha.com/joeandsekou>

* **Madou Sidiki Diabate**

<https://myspace.com/madousidikidiabate>

* **Ame Kora**

<http://www.amekoramusic.com/>

* **Vieux Aliou Cissokho**

<https://soundcloud.com/vieuxalioucissokho>

* **N'Faly Kouyate**

<http://nfaly.com/>

* **Jacques Burtin**

<http://www.jacquesburtin.com/koraEn.htm>

* **Ravi Ji**

<https://www.koratone.com/>

* **Holly Marland**

<https://koraqueen.wordpress.com/>

<https://hollymarlandmusic.com/>

* **Saliou Cissokho** 

<http://www.saliou-cissokho.de/> (German Language)

* **Kandara Diebaté**

https://www.nomadmusic.de/ (German Language)

* **Nathalie Cora**

<hhp://www.nathaliecora.com/>

Please use the contact form, at the top of the page, for additions or corrections.
