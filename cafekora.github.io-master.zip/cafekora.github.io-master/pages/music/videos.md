---
layout: page-fullwidth
show_meta: false
title: "Kora Videos"
header:
   image_fullwidth: "header_homepage_13.jpg"
permalink: "/music/videos/"

---
Our selection of some of the best kora videos on the internet.

<div class="row">

  <div class="large-4 columns">
<a href="{{ site.url }}{{ site.baseurl }}/music/videos2/">
<img src="https://img.youtube.com/vi/9zfAYKyDhAA/0.jpg" 
alt="Toumani Diabate The Mande Variations" width="300" height="225" border="5" /></a>
 Toumani Diabate The Mande Variations
</div>
 <div class="large-4 columns">
<a href="{{ site.url }}{{ site.baseurl }}/music/videos3/">
<img src="https://img.youtube.com/vi/Lx7hhA0Aits/0.jpg" 
alt="Toumani Diabate New Ancient Strings" width="300" height="225" border="5" /></a>
Toumani Diabate New Ancient Strings   
</div>
 <div class="large-4 columns">
<a href="{{ site.url }}{{ site.baseurl }}/music/videos4/">
<img src="https://img.youtube.com/vi/NiXgWghf2mE/0.jpg" 
alt="Sousou & Maher Cissoko: Jaliya Mouta" width="300" height="225" border="5" /></a>
Sousou & Maher Cissoko: Jaliya Mouta  
</div>
</div>
***
<div class="row">
<div class="large-4 columns">
<a href="{{ site.url }}{{ site.baseurl }}/music/videos5/">
<img src="https://img.youtube.com/vi/qPsvNN2iIrQ/0.jpg" 
alt="Toumani and Sidiki" width="300" height="225" border="5" /></a>
Toumani and Sidiki 
 </div>
 <div class="large-4 columns">
<a href="{{ site.url }}{{ site.baseurl }}/music/videos6/">
<img src="https://img.youtube.com/vi/oToZfPGMMBY/0.jpg" 
alt="Sona Jobarteh Jarabi" width="300" height="225" border="5" /></a>
Sona Jobarteh Jarabi
</div>
 <div class="large-4 columns">
<a href="{{ site.url }}{{ site.baseurl }}/music/videos7/">
<img src="https://img.youtube.com/vi/zVfx_m5--cQ/0.jpg" 
alt="Seckou Keita The Invisible Man" width="300" height="225" border="5" /></a>
Seckou Keita The Invisible Man
</div> 
</div>
***
<div class="row">
<div class="large-4 columns">
<a href="{{ site.url }}{{ site.baseurl }}/music/videos8/">
<img src="https://img.youtube.com/vi/LhaEq1cbJUk/0.jpg" 
alt="Cordes Anciennes" width="300" height="225" border="5" /></a>
Cordes Anciennes 
 </div>
 <div class="large-4 columns">
<a href="{{ site.url }}{{ site.baseurl }}/music/videos9/">
<img src="https://img.youtube.com/vi/j0B-WeDkkDY/0.jpg" 
alt="Lalo Keba Drame" width="300" height="225" border="5" /></a>
Lalo Keba Drame
</div>
 <div class="large-4 columns">
<a href="{{ site.url }}{{ site.baseurl }}/music/videos10/">
<img src="https://img.youtube.com/vi/v64oA-EQesY/0.jpg" 
alt="Jalikunda Cissokho" width="300" height="225" border="5" /></a>
Jalikunda Cissokho
</div> 
</div>
***
Want to suggest other videos we should include here? Please use the contact form at the top of the page.
