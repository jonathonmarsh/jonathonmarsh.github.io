---
layout: video
show_meta: false
title: "Toumani Diabate Mande Variations"
permalink: "/music/videos2/"

iframe: "<iframe width='970' height='546' src='//www.youtube.com/embed/9zfAYKyDhAA' frameborder='0' allowfullscreen></iframe>"
#
# These video settings are totally optional. It's only purpose
# is SEO, so that videos show up in Google hopefully with a 
# thumbnail.
# More › https://developers.google.com/webmasters/videosearch/schema?hl=en&rd=1
#
# embedURL – A URL pointing to a player for the specific video.
# contentURL – A URL pointing to the actual video media file
# thumbnailUrl – A URL pointing to the video thumbnail image file.
#
video:
    embedURL: "https://www.youtube.com/embed/9zfAYKyDhAA"
    contentURL: "https://www.youtube.com/watch?v=9zfAYKyDhAA"
    thumbnailUrl: "http://img.youtube.com/vi/9zfAYKyDhAA/maxresdefault.jpg"
---
- **<a href="{{ site.url }}{{ site.baseurl }}/music/videos/"> Back to Video list</a>**
