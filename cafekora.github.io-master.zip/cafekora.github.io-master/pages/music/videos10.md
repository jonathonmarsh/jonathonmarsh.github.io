---
layout: video
show_meta: false
title: "Jalikunda Cissokho"
permalink: "/music/videos10/"

iframe: "<iframe width='970' height='546' src='//www.youtube.com/embed/v64oA-EQesY' frameborder='0' allowfullscreen></iframe>"
#
# These video settings are totally optional. It's only purpose
# is SEO, so that videos show up in Google hopefully with a 
# thumbnail.
# More › https://developers.google.com/webmasters/videosearch/schema?hl=en&rd=1
#
# embedURL – A URL pointing to a player for the specific video.
# contentURL – A URL pointing to the actual video media file
# thumbnailUrl – A URL pointing to the video thumbnail image file.
#
video:
    embedURL: "https://www.youtube.com/embed/v64oA-EQesY"
    contentURL: "https://www.youtube.com/watch?v=v64oA-EQesY"
    thumbnailUrl: "https://img.youtube.com/vi/v64oA-EQesY/maxresdefault.jpg"
    
---
- **<a href="{{ site.url }}{{ site.baseurl }}/music/videos/"> Back to Video list</a>**
