---
layout: page
show_meta: false
title: Learning kora tunes
header:
   image_fullwidth: "BallakeSissokoKora.jpg"
permalink: "/tunes/"
---
In this section of the website, we'll provide some very simple introductions to some traditional kora pieces.

At the moment, there's only one song - more to follow!

- **<a href="{{ site.url }}{{ site.baseurl }}/tunes/bani/">Bani ›</a>** The song Bani (or Bani Le) "Refusal" 
