---
layout: page
show_meta: false
title: "Music"
header:
   image_fullwidth: "header_homepage_13.jpg"
permalink: "/music/"
---
This section includes pages on

- **<a href="{{ site.url }}{{ site.baseurl }}/music/koramusic/">Kora Music ›</a>** (the music traditionally played on the kora) 
- **<a href="{{ site.url }}{{ site.baseurl }}/music/recordings/">Recordings ›</a>** (links to some of the best kora recordings)
- **<a href="{{ site.url }}{{ site.baseurl }}/music/videos/">Videos ›</a>** (links to great videos on YouTube and elsewhere)
