---
layout: page
show_meta: false
title: "Music"
header:
   image_fullwidth: "header_homepage_13.jpg"
permalink: "/learn/"
---
This section includes pages on learning to play the kora.

- **<a href="{{ site.url }}{{ site.baseurl }}/learn/buying/">Buying ›</a>** Things to know when buying a kora 
- **<a href="{{ site.url }}{{ site.baseurl }}/learn/tuning/">Tuning ›</a>** How to tune a kora 
- **<a href="{{ site.url }}{{ site.baseurl }}/learn/practice/">Practice ›</a>** Some practice hints and tips 
- **<a href="{{ site.url }}{{ site.baseurl }}/learn/notation/">Notation ›</a>** Writing down kora music 
